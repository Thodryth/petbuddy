package de.codingclover.petbuddy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetbuddyApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetbuddyApplication.class, args);
	}

}
